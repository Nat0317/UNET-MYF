import time
import json
import os
from datetime import timedelta
import torch
from models.unet import UNet, UNetD, UNet64D, UNet4, UNet8, UNet16, Attention
from models.unet import UNet32, UNetMutiOutputs, UNetRes50, Res50DeepLab, UNetRes50DeepLab
from models.deeplab.deeplab import *
from args import argument_parser, dataset_kwargs, optimizer_kwargs, lr_scheduler_kwargs, loss_kwargs
from dataloader.data_loader import DataLoader
from optimizers import init_optimizer
from lr_schedulers import init_lr_scheduler
from utils.utils import create_path, delete_old_model, save_results, contour2weight
from utils.utils import count_num_param, resume_from_checkpoint, save_checkpoint
from tensorboardX import SummaryWriter
from validation import validation
from loss import Loss

# global variables
torch.backends.cudnn.benchmark = True
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
parser = argument_parser()
args = parser.parse_args()


def main():
    max_epoch = args.max_epoch

    print('Initializing image dataloader')
    datasets = DataLoader(**dataset_kwargs(args))
    trainloader = datasets.train_loader
    testloader = datasets.test_loader
    print('Initializing model.')
    if args.model == 'UNet':
        model = UNet(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm,
                     attention=args.attention).to(device)
    elif args.model == 'UNetD':
        model = UNetD(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNet64D':
        model = UNet64D(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNet4':
        model = UNet4(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNet8':
        model = UNet8(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNet16':
        model = UNet16(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNet32':
        model = UNet32(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNetMutiOutputs':
        model = UNetMutiOutputs(n_channels=3, n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNetRes50':
        model = UNetRes50(n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'UNetRes50DeepLab':
        model = UNetRes50DeepLab(n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    elif args.model == 'DeepLab':
        model = DeepLab(n_classes=1).to(device)
    elif args.model == 'Res50DeepLab':
        model = Res50DeepLab(n_classes=1).to(device)
    elif args.model == 'Attention':
        model = Attention(n_classes=1, up_mode=args.up_mode, batch_norm=args.batch_norm).to(device)
    print('Model size: {:.3f} M'.format(count_num_param(model)))

    optimizer = init_optimizer(model=model, **optimizer_kwargs(args))
    scheduler = init_lr_scheduler(optimizer, **lr_scheduler_kwargs(args))

    if args.resume:
        if os.path.isdir(args.resume_model_path):
            model_path = args.resume_model_path
            model, start_epoch = resume_from_checkpoint(model_path, model, optimizer=optimizer)
            max_epoch = max_epoch + start_epoch
        else:
            raise ValueError('Can not resume training, path: {} not exist'.format(args.resume_model_path))
    else:
        model_path = create_path(args.model, args.model_path, args.dataset, args.lr, args.max_epoch, args.optim,
                                 args.lr_scheduler, args.up_mode, args.augmentation, args.loss_type)
        start_epoch = 1
        os.makedirs(model_path)
        with open(model_path + '/args.txt', 'w+') as f:
            json.dump(args.__dict__, f, indent=2)

    writer = SummaryWriter(os.path.join(model_path), 'log')
    acc_temp = 0.0

    for epoch in range(start_epoch, max_epoch + 1):
        if args.model == 'UNetMutiOutputs':
            epoch_train_results = trainM(epoch, model, optimizer, trainloader, max_epoch, writer)
        else:
            epoch_train_results = train(epoch, model, optimizer, trainloader, max_epoch, writer)
        save_results(model_path, epoch_train_results, 'train')
        scheduler.step()

        if epoch % 5 == 0:
            print('Start evaluate')
            acc, epoch_val_results = validation(epoch, model, testloader, device, writer)
            save_results(model_path, epoch_val_results, 'val')
            print('Evaluation end\n')

            if acc > acc_temp:
                acc_temp = acc
                delete_old_model(model_path)
                save_checkpoint({
                    'state_dict': model.state_dict(),
                    'epoch': epoch,
                    'optimizer': optimizer.state_dict(),
                }, model_path)

    # dummy_input = torch.Tensor(torch.rand(args.train_batch_size, 3, args.width, args.height))
    # writer.add_graph(model, dummy_input)
    writer.close()


def trainM(epoch, model, optimizer, trainloader, max_epoch, writer):
    epoch_start_time = time.time()
    model.train()

    epoch_loss = 0.0
    tot1 = 0.0
    tot2 = 0.0
    sum = 0

    for batch_id, (x, y, contour) in enumerate(trainloader):
        x = x.to(device)  # [N, 1, H, W]
        y = y.to(device)  # [N, H, W] with class indices (0, 1)
        contour = contour.to(device)
        optimizer.zero_grad()
        prediction_d, prediction_s = model(x)  # [N, 2, H, W]
        contour_weight = contour2weight(contour, args.contour_weight).to(device)
        design_loss = Loss(contour_weight, **loss_kwargs)
        loss1, dice_loss1 = design_loss(prediction_d, y)
        loss2, dice_loss2 = design_loss(prediction_s, y)
        loss = loss1 + loss2
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()
        tot1 += dice_loss1
        tot2 += dice_loss2
        sum += 1

    acc1 = tot1 / sum
    acc2 = tot2 / sum
    epoch_loss = epoch_loss / sum
    elapsed = time.time() - epoch_start_time
    seconds_todo = (max_epoch - epoch) * elapsed
    epoch_train_results = 'Epoch[{}] - Loss: {} - Acc D: {} - Acc S: {} - Elapsed: {} - ETA: {}\n'.format(
        epoch, epoch_loss, acc1, acc2, timedelta(seconds=round(elapsed)),
        timedelta(seconds=int(seconds_todo)))
    print(epoch_train_results)

    writer.add_scalar('scalar/train_loss', epoch_loss, epoch)
    writer.add_scalar('scalar/train_acc', acc1, epoch)
    writer.add_scalar('scalar/train_acc', acc2, epoch)
    return epoch_train_results


def train(epoch, model, optimizer, trainloader, max_epoch, writer):
    epoch_start_time = time.time()
    model.train()

    epoch_loss = 0.0
    tot = 0.0
    sum = 0

    for batch_id, (x, y, contour) in enumerate(trainloader):
        x = x.to(device)  # [N, 1, H, W]
        y = y.to(device)  # [N, H, W] with class indices (0, 1)
        contour = contour.to(device)
        optimizer.zero_grad()
        prediction = model(x)  # [N, 2, H, W]
        contour_weight = contour2weight(contour, args.contour_weight).to(device)
        design_loss = Loss(contour_weight, **loss_kwargs(args))
        loss, bce_loss, dice_loss = design_loss(prediction, y)
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()
        tot += dice_loss
        sum += 1

    acc = tot / sum
    epoch_loss = epoch_loss / sum
    elapsed = time.time() - epoch_start_time
    seconds_todo = (max_epoch - epoch) * elapsed
    epoch_train_results = 'Epoch[{}] - Loss: {} - Acc: {} - Elapsed: {} - ETA: {}\n'.format(
        epoch, epoch_loss, acc, timedelta(seconds=round(elapsed)),
        timedelta(seconds=int(seconds_todo)))
    print(epoch_train_results)

    writer.add_scalar('scalar/train_loss', epoch_loss, epoch)
    writer.add_scalar('scalar/train_acc', acc, epoch)
    return epoch_train_results


if __name__ == '__main__':
    main()
