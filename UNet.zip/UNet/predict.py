import time
import datetime
import os
import json
import argparse
import torch
import matplotlib.pyplot as plt
import numpy as np
from torchvision import transforms
from models.unet import UNet
import PIL.Image as Image

parser = argparse.ArgumentParser(description='polyp_predict')

parser.add_argument('--image_path',
                    default='/home/xinzi/ExtDisk/polyp_detection_data/ETIS-LaribPolypDB/Original/100.tif',
                    help='path of image file')

parser.add_argument('--model_path',
                    default='/home/xinzi/ExtDisk/polyp_detection_model/'
                            'UNet_ETIS-LaribPolypDB_5e-05_650_adam_cosine_step_interpolate_augmentation',
                    help='path of model file')

opt = parser.parse_args()

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def plot_img_and_mask(img, mask):
    fig = plt.figure()
    a = fig.add_subplot(1, 2, 1)
    a.set_title('Input image')
    plt.imshow(img)

    b = fig.add_subplot(1, 2, 2)
    b.set_title('Output mask')
    plt.imshow(mask, cmap='gray')
    plt.show()


def get_output_filenames(args):
    in_files = args.input
    out_files = []

    if not args.output:
        for f in in_files:
            pathsplit = os.path.splitext(f)
            out_files.append("{}_OUT{}".format(pathsplit[0], pathsplit[1]))
    elif len(in_files) != len(args.output):
        print('Error : Input files and output files are not of the same length')
        raise SystemExit()
    else:
        out_files = args.output

    return out_files


def mask_to_image(mask):
    return Image.fromarray((mask * 255).astype(np.uint8))


def predict():
    args = json.load(open(os.path.join(opt.model_path, 'args.txt')))
    up_mode = args['up_mode']
    batch_norm = args['batch_norm']

    model_path = opt.model_path
    for filename in os.listdir(model_path):
        if filename.find('model_') != -1:
            model_path = os.path.join(model_path, filename)
            break

    loading_start_time = time.time()
    print('Start loading model')
    model = UNet(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    model.load_state_dict(torch.load(model_path)['state_dict'])
    model.eval()
    loading_elapsed = round(time.time() - loading_start_time)
    loading_elapsed = str(datetime.timedelta(milliseconds=loading_elapsed))
    print('\nModel loaded ! Loading elapsed: %s' % loading_elapsed)

    process_start_time = time.time()
    original_img = Image.open(opt.image_path)
    transform = transforms.Compose([
        transforms.Resize((512, 384), interpolation=3),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.3939, 0.4082, 0.4495], std=[0.2625, 0.2664, 0.2724])
    ])
    img = transform(original_img).to(device)
    img = img.unsqueeze(0)
    mask = model(img)
    process_elapsed = time.time() - process_start_time
    process_elapsed = str(datetime.timedelta(seconds=process_elapsed))
    print('\nProcessing elapsed: %s' % process_elapsed)

    original_img = original_img.resize((512, 384)) 
    mask = mask[0].squeeze(0).cpu().detach().numpy()
    mask = (mask > 0.5)
    mask = mask_to_image(mask).resize((512, 384))
    print('Visualizing results for image.')
    plot_img_and_mask(original_img, mask)

    # if not args.no_save:
    #     out_fn = out_files[i]
    #     result = mask_to_image(mask)
    #     result.save(out_files[i])
    #
    #     print("Mask saved to {}".format(out_files[i]))


if __name__ == '__main__':
    predict()
