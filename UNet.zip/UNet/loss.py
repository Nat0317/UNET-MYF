from torch.nn import BCELoss
import torch
from torch.nn.modules import loss
from utils.dice_loss import dice_coeff
import torch.nn.functional as F

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class Loss(loss._Loss):
    def __init__(self,
                 contour_weight,
                 type,
                 hard_negative_mining,
                 bce_loss_weight = 1,
                 hnm_ratio=3,
                 hnm_threshold=0.3,
                 hnm_threshold_auto=False
                 ):
        super(Loss, self).__init__()
        self.type = type
        self.contour_weight = contour_weight
        self.hard_negative_mining = hard_negative_mining
        self.bce_loss_weight = bce_loss_weight
        self.dice_loss_weight = 1 - bce_loss_weight
        self.hnm_ratio = hnm_ratio
        self.hnm_threshold = hnm_threshold
        self.hnm_threshold_auto = hnm_threshold_auto

    def forward(self, outputs, labels):
        predictions = (outputs > 0.5).float()
        dice_loss = dice_coeff(predictions, labels)
        dice_c = dice_loss.item()

        if self.hard_negative_mining == 'ratio':
            b, _, h, w = outputs.shape
            outputs = outputs.view(b, -1)
            labels = labels.view(b, -1)
            weight = self.contour_weight.view(b, -1)
            pos = labels != 0
            positive_num = torch.sum(pos, dim=1, keepdim=True)
            negtive_num = torch.sum(labels == 0, dim=1, keepdim=True)
            o_copy = outputs.clone()
            o_copy[pos] = 0
            _, i = torch.sort(o_copy, descending=True, dim=1)
            _, ii = torch.sort(i, dim=1)
            topk = torch.min(positive_num * 4, negtive_num)
            negative_pixel = ii < topk
            positive_pixel = pos
            chose_pixel = negative_pixel + positive_pixel

            weight[chose_pixel == 0] = 0
            outputs = outputs.view(b, 1, h, w)
            labels = labels.view(b, 1, h, w)
            self.contour_weight = weight.view(b, 1, h, w)

        elif self.hard_negative_mining == 'threshold':
            if self.hnm_threshold_auto:
                self.contour_weight[torch.mul(labels == 0, outputs < (1 - dice_c))] = 0
            else:
                self.contour_weight[torch.mul(labels == 0, outputs < self.hnm_threshold)] = 0

        if self.type == 'bce':
            bce_criterion = BCELoss(weight=self.contour_weight).to(device)
        elif self.type == 'focal_loss':
            bce_criterion = SegmentationLosses(weight=self.contour_weight).build_loss(mode='focal')
        else:
            raise ValueError('Unsupported loss type: {}'.format(self.type))

        bce_loss = bce_criterion(outputs, labels)

        loss = bce_loss * self.bce_loss_weight + (1 - dice_c) * self.dice_loss_weight

        return loss, bce_loss, dice_c


class FocalLoss2d(torch.nn.Module):
    def __init__(self, alpha=0.5, gamma=2, size_average=True):
        super(FocalLoss2d, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.size_average = size_average

    def forward(self, output, target):
        target = target.view(-1, 1).long()

        if self.alpha is None:
            class_weight = [1] * 2
        else:
            class_weight = [self.alpha, 1 - self.alpha]  # [0.25, 0.75]
        prob = output.view(-1, 1)
        prob = torch.cat((1 - prob, prob), 1)
        select = torch.FloatTensor(len(prob), 2).zero_().cuda()
        select.scatter_(1, target, 1.)

        class_weight = torch.FloatTensor(class_weight).cuda().view(-1, 1)
        class_weight = torch.gather(class_weight, 0, target)
        prob = (prob * select).sum(1).view(-1, 1)
        prob = torch.clamp(prob, 1e-8, 1 - 1e-8)
        batch_loss = - class_weight * (torch.pow((1 - prob), self.gamma)) * prob.log()
        if self.size_average:
            loss = batch_loss.mean()
        else:
            loss = batch_loss
        return loss


class SegmentationLosses(object):
    def __init__(self, weight=None, size_average=True, batch_average=True, ignore_index=255, cuda=False):
        self.ignore_index = ignore_index
        self.weight = weight
        self.size_average = size_average
        self.batch_average = batch_average
        self.cuda = cuda

    def build_loss(self, mode='ce'):
        """Choices: ['ce' or 'focal']"""
        if mode == 'ce':
            return self.CrossEntropyLoss
        elif mode == 'focal':
            return self.FocalLoss
        else:
            raise NotImplementedError

    def CrossEntropyLoss(self, logit, target):
        n, c, h, w = logit.size()
        criterion = torch.nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index,
                                        size_average=self.size_average)
        if self.cuda:
            criterion = criterion.cuda()

        loss = criterion(logit, target.long())

        if self.batch_average:
            loss /= n

        return loss

    def FocalLoss(self, logit, target, gamma=2, alpha=0.5):
        n, c, h, w = logit.size()
        criterion = torch.nn.BCELoss(weight=self.weight, ignore_index=self.ignore_index,
                                        size_average=self.size_average)
        if self.cuda:
            criterion = criterion.cuda()

        logpt = -criterion(logit, target.long())
        pt = torch.exp(logpt)
        if alpha is not None:
            logpt *= alpha
        loss = -((1 - pt) ** gamma) * logpt

        if self.batch_average:
            loss /= n

        return loss