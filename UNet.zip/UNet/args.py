import argparse


def argument_parser():
    parser = argparse.ArgumentParser(description='polyp')

    # ************************************************************
    # Training hyperparameters
    # ************************************************************
    parser.add_argument('--model', default='UNet',
                        choices=['UNet', 'UNetD', 'UNet64D', 'UNet4', 'UNet8', 'Attention',
                                 'UNet16', 'UNet32', 'UNetRes50', 'UNetRes50DeepLab',
                                 'DeepLab', 'Res50DeepLab'],
                        help='choose the model to use')
    parser.add_argument('--max-epoch', default=80,
                        help='number of epoch to train')
    parser.add_argument('--batch-norm', action='store_true',
                        help='use batch normalization or not')
    parser.add_argument('--up-mode', default='interpolate', choices=['transpose', 'interpolate'],
                        help='upsampling mode')
    parser.add_argument('--attention', action='store_true',
                        help='use attention mechanism or not after each stage in down path')

    # ************************************************************
    # Dataset setting
    # ************************************************************
    parser.add_argument('--data-path', default='/home/xinzi/ExtDisk/polyp_detection_data',
                        help='path of polyp datasets')
    parser.add_argument('--dataset', default='large_dataset',
                        choices=['CVC-ClinicDB', 'CVC-ClinicDB_augmentation', 'ETIS-LaribPolypDB',
                                 'large_dataset_ETIS_90000',
                                 'ETIS-LaribPolypDB_augmentation', 'large_dataset', 'large_dataset_90000'],
                        help='the name of the dataset')
    parser.add_argument('--train-batch-size', type=int, default=8,
                        help='the batch id of input image')
    parser.add_argument('--test-batch-size', type=int, default=4,
                        help='the batch id of input image')
    parser.add_argument('--augmentation', action='store_true',
                        help='use data augmentation or not')
    parser.add_argument('--workers', default=8, type=int,
                        help='number of data loading workers (tips: 4 or 8 times number of gpus)')
    parser.add_argument('--pin-memory', action='store_true',
                        help='True, the data loader will copy tensors into CUDA pinned memory.')
    parser.add_argument('--height', type=int, default=384,
                        help='height of an image')
    parser.add_argument('--width', type=int, default=384,
                        help='width of an image')

    # ************************************************************
    # Optimization options
    # ************************************************************
    parser.add_argument('--optim', type=str, default='adam', choices=['adam', 'amsgrad', 'sgd', 'rmsprop'],
                        help='optimization algorithm (see optimizers.py)')
    parser.add_argument('--lr', default=1e-5, type=float,
                        help='initial learning rate')
    parser.add_argument('--weight-decay', default=5e-04, type=float,
                        help='weight decay')
    # sgd
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum factor for sgd and rmsprop')
    parser.add_argument('--sgd-dampening', default=0, type=float,
                        help='sgd\'s dampening for momentum')
    parser.add_argument('--sgd-nesterov', action='store_true',
                        help='whether to enable sgd\'s Nesterov momentum')
    # rmsprop
    parser.add_argument('--rmsprop-alpha', default=0.99, type=float,
                        help='rmsprop\'s smoothing constant')
    # adam/amsgrad
    parser.add_argument('--adam-beta1', default=0.9, type=float,
                        help='exponential decay rate for adam\'s first moment')
    parser.add_argument('--adam-beta2', default=0.999, type=float,
                        help='exponential decay rate for adam\'s second moment')

    # ************************************************************
    # Learning rate scheduler options
    # ************************************************************
    parser.add_argument('--lr-scheduler', type=str, default='cosine_step',
                        choices=['single_step', 'multi_step', 'cosine_step'],
                        help='learning rate scheduler (see lr_schedulers.py)')
    parser.add_argument('--stepsize', default=[20, 40, 60], nargs='+', type=int,
                        help='stepsize to decay learning rate')
    parser.add_argument('--gamma', default=0.1, type=float,
                        help='learning rate decay')

    # ************************************************************
    # Loss options
    # ************************************************************
    parser.add_argument('--hard-negative-mining', type=str, default=None,
                        choices=['None', 'ratio', 'threshold'],
                        help='choose the mode of hard negative mining')
    parser.add_argument('--hnm-ratio', type=int, default=3,
                        help='if the hard-negative-mining is set to ratio, what is the ratio')
    parser.add_argument('--hnm-threshold', type=float, default=0.3,
                        help='if the hard-negative-mining is set to ratio, what is the threshold')
    parser.add_argument('--hnm-threshold-auto', action='store_true',
                        help='set the hard negative mining according to dice coefficient')
    parser.add_argument('--contour-weight', type=int, default=2,
                        help='')
    parser.add_argument('--loss-type', type=str, default='bce', choices=['bce', 'focal_loss'],
                        help='choose the type of loss')

    # ************************************************************
    # Other options
    # ************************************************************
    parser.add_argument('--model-path', type=str, default='/home/xinzi/ExtDisk/polyp_detection_model',
                        help='path to save the model')
    parser.add_argument('--resume', action='store_true',
                        help='resume from a checkpoint')
    parser.add_argument('--resume-model-path', type=str, default=None,
                        help='resume from a checkpoint')
    return parser


def dataset_kwargs(parsed_args):
    """
    Build kwargs for Dataset in data_loader.py from
    the parsed command-line arguments.
    """
    return {
        'data_path': parsed_args.data_path,
        'dataset_name': parsed_args.dataset,
        'train_batch_size': parsed_args.train_batch_size,
        'test_batch_size': parsed_args.test_batch_size,
        'augmentation': parsed_args.augmentation,
        'width': parsed_args.width,
        'height': parsed_args.height,
        'num_workers': parsed_args.workers,
        'pin_memory': parsed_args.pin_memory
    }


def optimizer_kwargs(parsed_args):
    """
    Build kwargs for optimizer in optimizers.py from
    the parsed command-line arguments.
    """
    return {
        'optim': parsed_args.optim,
        'lr': parsed_args.lr,
        'weight_decay': parsed_args.weight_decay,
        'momentum': parsed_args.momentum,
        'sgd_dampening': parsed_args.sgd_dampening,
        'sgd_nesterov': parsed_args.sgd_nesterov,
        'rmsprop_alpha': parsed_args.rmsprop_alpha,
        'adam_beta1': parsed_args.adam_beta1,
        'adam_beta2': parsed_args.adam_beta2
    }


def lr_scheduler_kwargs(parsed_args):
    """
    Build kwargs for lr_scheduler in lr_schedulers.py from
    the parsed command-line arguments.
    """
    return {
        'max_epoch': parsed_args.max_epoch,
        'lr_scheduler': parsed_args.lr_scheduler,
        'stepsize': parsed_args.stepsize,
        'gamma': parsed_args.gamma
    }


def loss_kwargs(parsed_args):
    """
    Build kwargs for lr_scheduler in lr_schedulers.py from
    the parsed command-line arguments.
    """
    return {
        'type': parsed_args.loss_type,
        'hard_negative_mining': parsed_args.hard_negative_mining,
        'hnm_ratio': parsed_args.hnm_ratio,
        'hnm_threshold': parsed_args.hnm_threshold,
        'hnm_threshold_auto': parsed_args.hnm_threshold_auto
    }
