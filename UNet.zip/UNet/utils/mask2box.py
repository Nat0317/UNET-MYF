import os
import pickle
import imageio
import scipy
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.ndimage import map_coordinates


def make_annots_file(data_root):
    img_prefix = os.path.join(data_root, 'Original')
    mask_prefix = os.path.join(data_root, 'GroundTruth')
    n = len(os.listdir(img_prefix))

    final_anns = []

    for i in range(1, n + 1):
        filename = '{:d}.tif'.format(i)
        ori_img = imageio.imread(os.path.join(img_prefix, filename))
        height, width, _ = ori_img.shape
        mask = imageio.imread(os.path.join(mask_prefix, filename))
        annot = {'filename': filename, 'width': width, 'height': height}

        mask = (mask == 255)
        label_im, nb_labels = scipy.ndimage.label(mask)
        sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
        valid_seg_indices = []
        for seg_index, seg_size in enumerate(sizes):
            if seg_size > 1:
                valid_seg_indices.append(seg_index)
        mask_size = sizes < 10
        remove_pixel = mask_size[label_im]
        label_im[remove_pixel] = 0
        new_label_im, new_nb_labels = scipy.ndimage.label(label_im)
        rois = np.array([(new_label_im == ii) * 1 for ii in range(1, new_nb_labels + 1)])
        p_coords_list = []
        p_label_list = []
        p_roi_masks_list = []
        for rix, r in enumerate(rois):
            if np.sum(r != 0) > 0:  # check if the lesion survived data augmentation
                seg_ixs = np.argwhere(r != 0)
                coord_list = [np.min(seg_ixs[:, 1]) - 1, np.min(seg_ixs[:, 0]) - 1,
                              np.max(seg_ixs[:, 1]) + 1, np.max(seg_ixs[:, 0]) + 1]
                p_coords_list.append(coord_list)
                p_label_list.append(1)
                p_roi_masks_list.append(r)

        gt_bboxes = np.array(p_coords_list, dtype=np.float32)
        gt_labels = np.array(p_label_list, dtype=np.int64)
        gt_bboxes_ignore = np.zeros((0, 4), dtype=np.float32)
        gt_labels_ignore = np.array([], dtype=np.int64)
        ann = dict(bboxes=gt_bboxes,
                   labels=gt_labels,
                   bboxes_ignore=gt_bboxes_ignore,
                   labels_ignore=gt_labels_ignore)
        annot['ann'] = ann
        final_anns.append(annot)
        if new_nb_labels > 1:
            print('image:', i, 'shape:', mask.shape, 'number:', new_nb_labels)
            fig = plt.figure(figsize=(10, 5))
            a = fig.add_subplot(1, 3, 1)
            plt.imshow(mask)
            a.set_title('Mask')
            a = fig.add_subplot(1, 3, 2)
            plt.imshow(new_label_im)
            for p_coord in p_coords_list:
                x1, y1, x2, y2 = p_coord
                rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=1, edgecolor='r', facecolor='none')
                a.add_patch(rect)
            a.set_title('Label')
            plt.show()

    pickle.dump(final_anns, open(os.path.join(data_root, 'polyp_annots.pkl'), 'wb'))


if __name__ == '__main__':
    make_annots_file('/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB/')
    make_annots_file('/home/xinzi/ExtDisk/polyp_detection_data/ETIS-LaribPolypDB/')
