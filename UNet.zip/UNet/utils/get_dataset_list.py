import os
import shutil
import imageio
import PIL.Image as Image

# image_num = 1
# for i in range(1, 19):
#     p = '/home/xinzi/ExtDisk/polyp_detection_data/Task_1_Automatic_Polyp_Detection_in_Colon_Videos/' \
#         'Task_1_Automatic_Polyp_Detection_in_Colon_Videos/CVC-VideoClinicDBtrain_valid/' + str(i)
#
#     for filename in os.listdir(p):
#         if filename.find('_mask') != -1:
#             mask_path = os.path.join(p, filename)
#             mask = imageio.imread(mask_path)
#             if mask.max() == 255:
#                 shutil.copy(mask_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/'
#                                                     'large_dataset/train/GroundTruth', str(image_num) + '.png'))
#                 original_image_path = os.path.join(p, filename.split('_')[0] + '.png')
#                 shutil.copy(original_image_path, os.path.join('/home/xinzi/ExtDisk/'
#                                                               'polyp_detection_data/large_dataset/train/Original',
#                                                                str(image_num) + '.png'))
#                 image_num += 1


# image_num = 10026
#
# dataset_path = '/home/xinzi/ExtDisk/polyp_detection_data/Task_2_Polyp_Segmentation/Task_2_Polyp_Segmentation/cvc300/bbdd'
# gt_path = '/home/xinzi/ExtDisk/polyp_detection_data/Task_2_Polyp_Segmentation/Task_2_Polyp_Segmentation/cvc300/gtpolyp'
#
# for filename in os.listdir(dataset_path):
#     image_path = os.path.join(dataset_path, filename)
#     mask_path = os.path.join(gt_path, filename)
#     shutil.copy(image_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/large_dataset/'
#                                          'train/Original', str(image_num) + '.bmp'))
#     shutil.copy(mask_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/large_dataset/'
#                                         'train/GroundTruth', str(image_num) + '.bmp'))
#
#
#     image_num += 1

# image_num = 10326
# dataset_path = '/home/xinzi/ExtDisk/polyp_detection_data/ETIS-LaribPolypDB/Original/'
# gt_path = '/home/xinzi/ExtDisk/polyp_detection_data/ETIS-LaribPolypDB/GroundTruth/'
#
# for filename in os.listdir(dataset_path):
#     image_path = os.path.join(dataset_path, filename)
#     mask_path = os.path.join(gt_path, filename)
#     shutil.copy(image_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/large_dataset/'
#                                          'train/Original', str(image_num) + '.tif'))
#     shutil.copy(mask_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/large_dataset/'
#                                         'train/GroundTruth', str(image_num) + '.tif'))
#
#
#     image_num += 1


image_num = 10522

image_path = '/home/xinzi/ExtDisk/polyp_detection_data/Task_2_Polyp_Segmentation/Task_2_Polyp_Segmentation/SegmentationTrainingUpload'

for filename in os.listdir(image_path):
    if filename.find('_mask') != -1:
        mask_path = os.path.join(image_path, filename)

        shutil.copy(mask_path, os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/'
                                            'large_dataset/train/GroundTruth', str(image_num) + '.tif'))
        original_image_path = os.path.join(image_path, filename.split('_')[0] + '.bmp')
        original_image = imageio.imread(original_image_path)
        original_image = Image.fromarray(original_image)
        original_image.save(os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/'
                                            'large_dataset/train/Original', str(image_num) + '.tif'))
        image_num += 1