import os
import torch
import scipy
import cv2 as cv
import numpy as np
import torch.nn as nn
from scipy.ndimage import map_coordinates


def create_path(model, model_path, dataset, lr, max_epoch, optim, lr_scheduler, up_mode, augmentation, loss):
    model_path = model_path + '/' + model + '_' + str(dataset) + '_' + str(lr) + '_' + \
                 str(max_epoch) + '_' + str(optim) + '_' + str(lr_scheduler) + '_' + \
                 str(up_mode) + '_' + str(loss)
    if augmentation is True:
        model_path += '_' + 'augmentation'
    return model_path


def delete_old_model(model_path):
    for filename in os.listdir(model_path):
        if filename.find('model_') != -1:
            os.remove(os.path.join(model_path, filename))


def save_results(model_path, results, mode):
    if mode == 'train':
        results_file = open(model_path + '/train_results.txt', 'a')
    elif mode == 'val':
        results_file = open(model_path + '/validation_results.txt', 'a')
    else:
        raise ValueError('Unsupported mode: {}'.format(mode))

    results_file.write(results)
    results_file.close()


def count_num_param(model):
    num_param = sum(p.numel() for p in model.parameters()) / 1e+06

    if isinstance(model, nn.DataParallel):
        model = model.module

    if hasattr(model, 'classifier') and isinstance(model.classifier, nn.Module):
        # we ignore the classifier because it is unused at test time
        num_param -= sum(p.numel() for p in model.classifier.parameters()) / 1e+06
    return num_param


def save_checkpoint(state, save_dir):
    epoch = state['epoch']
    fpath = os.path.join(save_dir, 'model_{}.pt'.format(epoch))
    torch.save(state, fpath)
    # print('Checkpoint saved to "{}"'.format(fpath))


def resume_from_checkpoint(model_path, model, optimizer=None):
    ckpt_exist = False
    ckpt_path = ''

    for filename in os.listdir(model_path):
        if filename.find('model_') != -1:
            ckpt_path = os.path.join(model_path, filename)
            ckpt_exist = True

    if ckpt_exist:
        print('Loading checkpoint from "{}"'.format(ckpt_path))
    else:
        raise ValueError('Can not find model file!')

    ckpt = torch.load(ckpt_path)
    model.load_state_dict(ckpt['state_dict'])
    print('Loaded model weights')

    if optimizer is not None:
        optimizer.load_state_dict(ckpt['optimizer'])
        print('Loaded optimizer')
    start_epoch = ckpt['epoch']

    print('** previous epoch = {}'.format(start_epoch))
    return model, start_epoch


def smooth_mask(mask):
    kernel = cv.getStructuringElement(cv.MORPH_RECT, (5, 5))
    mask = cv.dilate(mask, kernel)
    mask = cv.erode(mask, kernel)
    return mask


def find_contours(mask):
    ret, thresh = cv.threshold(mask, 127, 255, 0)
    _, contours, hierarchy = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    img = np.zeros(mask.shape)
    cv.drawContours(img, contours, -1, 255, 1)
    return img / 255


def contour2weight(contour, weight):
    weight_map = torch.ones(contour.shape, dtype=torch.float).cuda()
    weight_map[contour != 0] = weight
    return weight_map


def apply_mask(image, mask, alpha=0.5):
    """Apply the given mask to the image.
    """
    # mask = cv.resize(mask, (image.shape[1], image.shape[0]))
    # color = np.random.rand(3)
    color = np.array([0, 0, 1])
    for c in range(3):
        image[:, :, c] = np.where(mask == 255,
                                  image[:, :, c] *
                                  (1 - alpha) + alpha * color[c] * 255,
                                  image[:, :, c])
    return image


def remove_small_area(mask, small_mask_threshold):
    label_im, nb_labels = scipy.ndimage.label(mask)
    sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
    valid_seg_indices = []
    for seg_index, seg_size in enumerate(sizes):
        if seg_size > 1:
            valid_seg_indices.append(seg_index)

    mask_size = sizes < small_mask_threshold
    remove_pixel = mask_size[label_im]
    # remove those tiny masks
    label_im[remove_pixel] = 0
    return label_im

# def scale_radius(img, scale):
#     ''' rescale image to have same radius
#     '''
#     x = img[img.shape[0] // 2, :, :].sum(1)
#     r = (x > x.mean() / 10).sum() / 2
#     s = scale * 1.0 / r
#     return cv.resize(img, (0, 0), fx=s, fy=s)
#
#
# def dataset_preprocess(in_path, out_path, scale):
#     ''' preprocessing module
#     '''
#     img_lst = get_filename_lst(in_path, lambda x: '.jpeg' in x)
#     for img_name in img_lst:
#         img_path = in_path + img_name
#         try:
#             img = cv.imread(img_path)
#
#             # scale img to a given radius, set scale = 300, 500 and 1000 are overkill
#             img = scale_radius(img, scale)
#
#             # remove outer 10%
#             b = np.zeros(img.shape)
#             cv.circle(b, (img.shape[1] // 2, img.shape[0] // 2), int(scale * 0.9), (1, 1, 1), -1, 8, 0)
#
#             # subtract local mean color
#             new_img = cv.addWeighted(img, 4, cv.GaussianBlur(img, (0, 0), scale / 30), -4, 128) * b + 128 * (1 - b)
#
#             # save to folder
#             cv.imwrite(out_path + img_name, new_img)
#         except Exception as e:
#             print(e)
