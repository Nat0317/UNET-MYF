import numpy as np
import cv2
import os
import scipy
import imageio
import math
import cv2 as cv
import PIL.Image as Image
from scipy.ndimage import map_coordinates


def smooth_mask(mask):
    kernel1 = cv.getStructuringElement(cv.MORPH_RECT, (7, 7))
    kernel2 = cv.getStructuringElement(cv.MORPH_RECT, (5, 5))
    mask = cv.dilate(mask, kernel1)
    mask = cv.erode(mask, kernel1)
    mask = cv.dilate(mask, kernel2)
    mask = cv.erode(mask, kernel2)
    return mask


def remove_small_area(mask, small_mask_threshold):
    label_im, nb_labels = scipy.ndimage.label(mask)
    sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
    valid_seg_indices = []
    for seg_index, seg_size in enumerate(sizes):
        if seg_size > 1:
            valid_seg_indices.append(seg_index)

    mask_size = sizes < small_mask_threshold
    remove_pixel = mask_size[label_im]
    # remove those tiny masks
    label_im[remove_pixel] = 0
    return label_im


def apply_mask(image, mask, alpha=0.5):
    """Apply the given mask to the image.
    """
    # mask = cv.resize(mask, (image.shape[1], image.shape[0]))
    # color = np.random.rand(3)
    color = np.array([0, 0, 1])
    for c in range(3):
        image[:, :, c] = np.where(mask == 255,
                                  image[:, :, c] *
                                  (1 - alpha) + alpha * color[c] * 255,
                                  image[:, :, c])
    return image


def close_bbox(box1, box2):
    box1_ctx = box1[0] + (box1[2] - box1[0]) * 0.5
    box1_cty = box1[1] + (box1[3] - box1[1]) * 0.5

    box2_ctx = box2[0] + (box2[2] - box2[0]) * 0.5
    box2_cty = box2[1] + (box2[3] - box2[1]) * 0.5

    box1_diagonal = math.sqrt((box1[0] - box1[2]) ** 2 + (box1[1] - box1[3]) ** 2)
    box2_diagonal = math.sqrt((box2[0] - box2[2]) ** 2 + (box2[1] - box2[3]) ** 2)
    center_distance = math.sqrt((box1_ctx - box2_ctx) ** 2 + (box1_cty - box2_cty) ** 2)

    return center_distance <= (box1_diagonal + box2_diagonal) * 1.2 / 2


def bb_intersection_over_union(boxA, boxB):
    # determine the (x, y)-coordinates of the intersection rectangle
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    # compute the area of intersection rectangle
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)

    # compute the area of both the prediction and ground-truth
    # rectangles
    boxAArea = (boxA[2] - boxA[0] + 1) * (boxA[3] - boxA[1] + 1)
    boxBArea = (boxB[2] - boxB[0] + 1) * (boxB[3] - boxB[1] + 1)

    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = interArea / float(boxAArea + boxBArea - interArea)

    # return the intersection over union value
    return iou


class Evaluation(object):
    def __init__(self,
                 visualization_root,
                 mode='center',
                 iou_thresh=0,
                 visualize=False
                 ):

        self.TPs = []
        self.FNs = []
        self.FPs = []
        assert mode == 'center' or mode == 'iou', '({}) mode is not supported'
        self.mode = mode
        self.iou_thresh = iou_thresh
        self.FP_color = (0, 0, 255)
        self.Detection_color = (0, 255, 0)
        self.GT_color = (255, 0, 0)
        self.visualize = visualize
        if visualize:
            #  create image folder for saving detection result
            self.detection_folder = visualization_root + '/ALL/'
            self.false_positive_folder = visualization_root + '/FP/'
            self.false_negative_folder = visualization_root + '/FN/'
            os.makedirs(self.detection_folder)
            os.makedirs(self.false_positive_folder)
            os.makedirs(self.false_negative_folder)
            os.popen('rm -r ' + self.detection_folder + '*')
            os.popen('rm -r ' + self.false_positive_folder + '*')
            os.popen('rm -r ' + self.false_negative_folder + '*')

    def get_coord_list(self, path, small_mask, smooth=False):
        coord_list = []
        mask = imageio.imread(path)

        if smooth:
            mask = smooth_mask(mask)

        mask = (mask == 255)
        mask = remove_small_area(mask, small_mask)

        mask_label_im, mask_nb_labels = scipy.ndimage.label(mask)
        mask_rois = np.array([(mask_label_im == ii) * 1 for ii in range(1, mask_nb_labels + 1)])

        for rix, r in enumerate(mask_rois):
            if np.sum(r != 0) > 0:  # check if the lesion survived data augmentation
                seg_ixs = np.argwhere(r != 0)
                mask_coord_list = [np.min(seg_ixs[:, 1]) - 1, np.min(seg_ixs[:, 0]) - 1,
                                   np.max(seg_ixs[:, 1]) + 1, np.max(seg_ixs[:, 0]) + 1]
                coord_list.append(mask_coord_list)

        return coord_list, (mask != 0).astype(np.uint8) * 255

    def merge_close_bbox(self, boxes):
        # if there are no boxes, return an empty list
        if len(boxes) == 0:
            return boxes

        l = len(boxes)
        i = 0
        while i < l - 1:
            for j in range(0, l):
                if i != j and close_bbox(boxes[i], boxes[j]):
                    boxes[i] = [min(boxes[i][0], boxes[j][0]), min(boxes[i][1], boxes[j][1]),
                                max(boxes[i][2], boxes[j][2]), max(boxes[i][3], boxes[j][3])]

                    boxes[j] = None
            boxes = [box for box in boxes if box]
            l = len(boxes)
            i += 1
        return boxes

    def eval_add_result(self, ground_truth, pred_points, image=None, image_name=None, iou_threshold=0.0):
        if self.visualize:
            FPimage = image.copy()
            FNimage = image.copy()
            Detectionimage = image.copy()

            for pt in pred_points:
                pt1 = tuple([int(pt[0]), int(pt[1])])
                pt2 = tuple([int(pt[2]), int(pt[3])])
                cv2.rectangle(Detectionimage, pt1, pt2, self.Detection_color, 2)

        missing = False

        for index_gt_box, gt_box in enumerate(ground_truth):
            hasTP = False
            gt = gt_box

            not_matched = []
            for j in pred_points:
                if self.mode == 'center':
                    ctx = j[0] + (j[2] - j[0]) * 0.5
                    cty = j[1] + (j[3] - j[1]) * 0.5
                    bbox_matched = gt[0] < ctx < gt[2] and gt[1] < cty < gt[3]

                elif self.mode == 'iou':
                    bbox_matched = bb_intersection_over_union(gt, j) > iou_threshold

                if bbox_matched:
                    if not hasTP:
                        self.TPs.append(j)
                        hasTP = True

                else:
                    not_matched.append(j)
            pred_points = not_matched

            if not hasTP:
                self.FNs.append(gt)

                if self.visualize:
                    # Draw False negative rect
                    missing = True
                    pt1 = tuple([int(gt[0]), int(gt[1])])
                    pt2 = tuple([int(gt[2]), int(gt[3])])
                    cv2.rectangle(FNimage, pt1, pt2, self.GT_color, 2)

            if self.visualize:
                # Draw groundturth on detection and FP images
                pt1 = tuple([int(gt[0]), int(gt[1])])
                pt2 = tuple([int(gt[2]), int(gt[3])])
                cv2.rectangle(Detectionimage, pt1, pt2, self.GT_color, 2)
                cv2.rectangle(FPimage, pt1, pt2, self.GT_color, 2)

        if self.visualize:
            if missing:
                FNimage = Image.fromarray(FNimage)
                FNimage.save(self.false_negative_folder + str(image_name) + '.tif')
            Detectionimage = Image.fromarray(Detectionimage)
            Detectionimage.save(self.detection_folder + str(image_name) + '.tif')
        if len(pred_points) > 0 and self.visualize:
            # Draw false positive rect
            for fp in pred_points:
                pt1 = tuple([int(fp[0]), int(fp[1])])
                pt2 = tuple([int(fp[2]), int(fp[3])])
                cv2.rectangle(FPimage, pt1, pt2, self.FP_color, 2)
            FPimage = Image.fromarray(FPimage)
            FPimage.save(self.false_positive_folder + str(image_name) + '.tif')
        #  add FP here
        self.FPs += pred_points

    def get_result(self):
        precision = float(len(self.TPs)) / (len(self.TPs) + len(self.FPs))
        recall = float(len(self.TPs)) / (len(self.TPs) + len(self.FNs))
        return precision, recall

    def reset(self):
        self.TPs = []
        self.FNs = []
        self.FPs = []


if __name__ == '__main__':
    original_image_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/test/Original'
    ground_truth_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/test/GroundTruth'
    prediction_path = '/home/xinzi/ExtDisk/polyp_detection_model/' \
                      'UNet_CVC-ClinicDB_augmentation_5e-05_360_adam_cosine_step_interpolate/prediction'

    evaluation_metric = Evaluation(visualization_root='/home/xinzi/ExtDisk/polyp_detection_model/' \
                                                      'UNet_CVC-ClinicDB_augmentation_5e-05_360_adam_cosine_step_interpolate/'
                                                      'evaluation_images/',
                                   visualize=True, mode='iou')

    for filename in os.listdir(ground_truth_path):
        mask_gt_path = os.path.join(ground_truth_path, filename)
        mask_pred_path = os.path.join(prediction_path, filename)
        original_image = imageio.imread(os.path.join(original_image_path, filename))
        gt_coord, _ = evaluation_metric.get_coord_list(mask_gt_path, 10)
        pred_coord, pre_mask = evaluation_metric.get_coord_list(mask_pred_path, 80)
        pred_coord = evaluation_metric.merge_close_bbox(pred_coord)
        image = apply_mask(original_image, pre_mask)
        evaluation_metric.eval_add_result(gt_coord, pred_coord, image, filename[:-4])

    precision, recall = evaluation_metric.get_result()
    print('Recall: ', format(recall, '.2%'))
    print('Precision: ', format(precision, '.2%'))
