import os
import shutil
from sklearn.model_selection import train_test_split


def train_val_split(root):
    imgs = []

    n = len(os.listdir(root + '/Original/'))
    for i in range(1, n + 1):
        img = os.path.join(root, 'Original/%d.tif' % i)
        mask = os.path.join(root, 'GroundTruth/%d.tif' % i)
        imgs.append([img, mask])

    imgs_train, imgs_test = train_test_split(imgs, test_size=0.2)

    for i in imgs_train:
        filename = i[0].split('/')[-1]
        shutil.copyfile(i[0], os.path.join(root, 'train', 'Original', filename))
        shutil.copyfile(i[1], os.path.join(root, 'train', 'GroundTruth', filename))

    for i in imgs_test:
        filename = i[0].split('/')[-1]
        shutil.copyfile(i[0], os.path.join(root, 'test', 'Original', filename))
        shutil.copyfile(i[1], os.path.join(root, 'test', 'GroundTruth', filename))


if __name__ == '__main__':
    root = os.path.join('/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation')
    train_val_split(root)
