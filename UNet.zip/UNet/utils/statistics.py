import os
import imageio
import scipy
import seaborn as sns
import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
from scipy.ndimage import map_coordinates

sns.set()


def mask_size_distribution(data_root):
    result = []
    for filename in os.listdir(data_root):
        mask = imageio.imread(os.path.join(data_root, filename))
        mask = cv.resize(mask, (384, 384))

        mask = (mask == 255)
        # nb_label: number of mask, each mask has a unique label.   label_im: the label each pixel belongs to
        label_im, nb_labels = scipy.ndimage.label(mask)
        sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
        valid_seg_indices = []
        for seg_index, seg_size in enumerate(sizes):
            if seg_size > 1:
                valid_seg_indices.append(seg_index)

        mask_size = sizes < 20
        remove_pixel = mask_size[label_im]
        # remove those tiny masks
        label_im[remove_pixel] = 0
        # then find the number of masks again
        new_label_im, new_nb_labels = scipy.ndimage.label(label_im)

        # 3D, each channel represent a single mask
        rois = np.array([(new_label_im == ii) * 1 for ii in range(1, new_nb_labels + 1)])

        for rix, r in enumerate(rois):
            if np.sum(r != 0) > 0:  # check if the lesion survived data augmentation
                mask_size = np.sum(r)
                result.append(mask_size)
                if mask_size.min() <= 150:
                    print(filename)

    return result


def size_distribution(data_root):
    mask_image_ratio = []
    bbox_image_ratio = []
    mask_bbox_ratio = []

    mask_prefix = os.path.join(data_root, 'GroundTruth')
    image = imageio.imread(os.path.join(mask_prefix, '1.tif'))
    image_size = image.shape[0] * image.shape[1]

    n = len(os.listdir(mask_prefix))
    for i in range(1, n + 1):
        filename = '{:d}.tif'.format(i)
        mask = imageio.imread(os.path.join(mask_prefix, filename))

        mask = (mask == 255)
        # nb_label: number of mask, each mask has a unique label.   label_im: the label each pixel belongs to
        label_im, nb_labels = scipy.ndimage.label(mask)
        sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
        valid_seg_indices = []
        for seg_index, seg_size in enumerate(sizes):
            if seg_size > 1:
                valid_seg_indices.append(seg_index)

        mask_size = sizes < 10
        remove_pixel = mask_size[label_im]
        # remove those tiny masks
        label_im[remove_pixel] = 0
        # then find the number of masks again
        new_label_im, new_nb_labels = scipy.ndimage.label(label_im)

        # 3D, each channel represent a single mask
        rois = np.array([(new_label_im == ii) * 1 for ii in range(1, new_nb_labels + 1)])

        for rix, r in enumerate(rois):
            if np.sum(r != 0) > 0:  # check if the lesion survived data augmentation
                mask_size = np.sum(r)
                seg_ixs = np.argwhere(r != 0)
                bbox_size = (np.max(seg_ixs[:, 1]) - np.min(seg_ixs[:, 1]) + 32) * (
                        np.max(seg_ixs[:, 0]) - np.min(seg_ixs[:, 0]) + 3)

                mask_image_ratio.append(round(1.0 * mask_size / image_size, 3))
                bbox_image_ratio.append(round(1.0 * bbox_size / image_size, 3))
                mask_bbox_ratio.append(round(1.0 * mask_size / bbox_size, 3))

    return np.array(mask_image_ratio), np.array(bbox_image_ratio), np.array(mask_bbox_ratio)


def light_distribution(original_image_path, mask_path, predict_path):
    original_light = np.array([])
    masked_light = np.array([])
    predict_light = np.array([])

    for filename in os.listdir(original_image_path):
        image = cv.imread(os.path.join(original_image_path, filename), cv.IMREAD_GRAYSCALE)
        mask = imageio.imread(os.path.join(mask_path, filename))
        prediction = imageio.imread(os.path.join(predict_path, filename))
        original_light = np.append(original_light, image)
        masked_light = np.append(masked_light, image[mask==255])
        predict_light = np.append(predict_light, image[prediction==255])

    return original_light.tolist(), masked_light.tolist(), predict_light.tolist()


if __name__ == '__main__':
    # """
    # this block is for mask and bbox statistics
    # """
    # mask_image_ratio, bbox_image_ratio, mask_bbox_ratio = mask_size_distribution(
    #     '/Users/xinzisun/Downloads/polyp_data/CVC-ClinicDB/')
    #
    # sns.distplot(mask_image_ratio, kde_kws={"label":"mask/image"}, rug=True, bins=[i / 100.0 for i in range(0, 90)])
    # sns.distplot(bbox_image_ratio, kde_kws={"label":"bbox/image"}, rug=True, bins=[i / 100.0 for i in range(0, 90)])
    # sns.distplot(mask_bbox_ratio, kde_kws={"label":"mask/bbox"}, rug=True, bins=[i / 100.0 for i in range(0, 100)])
    #
    # plt.title('CVC-ClinicDB')
    # plt.show()



    # image_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/test/Original'
    # # image_path = '/Users/xinzisun/Downloads/polyp_data/CVC-ClinicDB/Original'
    #
    # mask_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/test/GroundTruth'
    # # mask_path = '/Users/xinzisun/Downloads/polyp_data/CVC-ClinicDB/GroundTruth'
    #
    # predict_path = '/home/xinzi/ExtDisk/polyp_detection_model/' \
    #                'UNet_CVC-ClinicDB_augmentation_5e-05_360_adam_cosine_step_interpolate/test_mask'
    # original_light, masked_light, predict_light = light_distribution(image_path, mask_path, predict_path)
    # sns.distplot(original_light, kde_kws={"label": "origianl_image light"}, rug=True)
    # sns.distplot(masked_light, kde_kws={"label": "ground truth light"}, rug=True)
    # sns.distplot(predict_light, kde_kws={"label": "prediction light"}, rug=True)
    #
    # plt.title('Light Distribution')
    # plt.savefig('/home/xinzi/distribution.png')
    # plt.show()

    image_path = '/home/xinzi/ExtDisk/polyp_detection_data/large_dataset/train/GroundTruth_orig'
    mask_size = mask_size_distribution(image_path)
    sns.distplot(mask_size, kde_kws={"label":"mask size"}, rug=True)

    plt.title('Mask Size Distribution')
    plt.savefig('/home/xinzi/mask_size_distribution.png')

    mask_size.sort()
    print(mask_size[0:20])