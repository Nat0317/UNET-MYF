import Augmentor
from Augmentor.Operations import Operation

class my_convert_mode(Operation):

    def __init__(self, probability):
        Operation.__init__(self, probability)

    def perform_operation(self, images):
        res = [i.convert('RGB') for i in images] #mode L, rgb, ...
        return res


def augmentation(original_image_path, output_path, mask_image_path):
    p = Augmentor.Pipeline(original_image_path, output_directory=output_path)
    p.add_operation(my_convert_mode(1))
    p.ground_truth(mask_image_path)
    p.rotate(probability=0.5, max_left_rotation=5, max_right_rotation=5)
    p.flip_random(probability=0.5)
    # p.crop_random(probability=0.5, percentage_area=0.8, randomise_percentage_area=False)
    p.random_distortion(probability=0.5, grid_width=4, grid_height=4, magnitude=1)
    p.zoom_random(probability=0.25, percentage_area=0.9)
    p.random_brightness(probability=0.5, min_factor=0.8, max_factor=1.3)
    p.random_contrast(probability=0.5, min_factor=0.8, max_factor=1.3)
    p.skew_tilt(probability=0.5)
    p.shear(probability=0.25, max_shear_left=20, max_shear_right=20)
    p.sample(90000)


if __name__ == '__main__':
    original_image_path = "/home/xinzi/ExtDisk/polyp_detection_data/large_dataset_ETIS_90000/train/Original_orig"
    output_path = '/home/xinzi/ExtDisk/polyp_detection_data/large_dataset_ETIS_90000/train/Original'
    mask_image_path = '/home/xinzi/ExtDisk/polyp_detection_data/large_dataset_ETIS_90000/train/GroundTruth_orig'
    augmentation(original_image_path, output_path, mask_image_path)
