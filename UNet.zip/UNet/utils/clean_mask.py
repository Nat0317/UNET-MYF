import imageio
import scipy
import os
import numpy as np
from scipy.ndimage import map_coordinates
import PIL.Image as Image


def clean_mask(path, save_path, small_mask_threshold):
    for filename in os.listdir(path):
        mask = imageio.imread(os.path.join(path, filename))
        mask = (mask > 127).astype(np.uint8)
        mask = remove_small_area(mask, small_mask_threshold)
        mask = (mask != 0).astype(np.uint8) * 255
        mask = Image.fromarray(mask)
        mask.save(os.path.join(save_path, filename))


def remove_small_area(mask, small_mask_threshold):
    label_im, nb_labels = scipy.ndimage.label(mask)
    sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))

    mask_size = sizes < small_mask_threshold
    remove_pixel = mask_size[label_im]
    # remove those tiny masks
    label_im[remove_pixel] = 0
    return label_im


if __name__ == '__main__':
    original_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/train/GroundTruth'
    save_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/train/GroundTruth_clean'
    clean_mask(original_path, save_path, 50)
