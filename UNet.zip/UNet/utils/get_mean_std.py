from torch.utils.data import dataset, dataloader
from torchvision import transforms
import torchvision.transforms.functional as tf
import PIL.Image as Image
import imageio
import cv2 as cv
import os


class DataLoader:
    def __init__(self,
                 data_path,  # image_path
                 batch_size,
                 width=512,  # width of image after resize
                 height=384,  # height of image after resize
                 num_workers=8,  # number of data loading workers (tips: 4 or 8 times number of gpus)
                 pin_memory=True  # whether to copy tensors into CUDA pinned memory before returning them
                 ):
        dataset = PolypDataset(data_path, width, height)
        self.data_loader = dataloader.DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                                 num_workers=num_workers, pin_memory=pin_memory)
        self.num_class = 2


def make_dataset(data_path):
    imgs = []
    root1 = os.path.join(data_path, 'large_d/train/Original')
    root2 = os.path.join(data_path, 'large_d/test/Original')

    for i in os.listdir(root1):
        img = os.path.join(root1, i)
        imgs.append(img)

    for i in os.listdir(root2):
        img = os.path.join(root2, i)
        imgs.append(img)
    return imgs


class PolypDataset(dataset.Dataset):
    def __init__(self, data_path, width, height):
        self.data_path = data_path
        self.width = width
        self.height = height
        imgs = make_dataset(self.data_path)
        self.imgs = imgs

    def __getitem__(self, index):
        transform = transforms.Compose([
            transforms.Resize((self.width, self.height), interpolation=3),
            transforms.ToTensor()
        ])
        x_path = self.imgs[index]
        img_x = imageio.imread(x_path)
        img_x = Image.fromarray(img_x)
        img_x = transform(img_x)
        return img_x

    def __len__(self):
        return len(self.imgs)


if __name__ == '__main__':
    image_path = '/home/xinzi/ExtDisk/polyp_detection_data'
    image_width = 384
    image_height = 384

    mean = 0.
    std = 0.

    data_loader = DataLoader(image_path, 16, image_width, image_height).data_loader
    for images in data_loader:
        batch_samples = images.size(0)  # batch size (the last batch can have smaller size!)
        images = images.view(batch_samples, images.size(1), -1)
        mean += images.mean(2).sum(0)
        std += images.std(2).sum(0)

    mean /= len(data_loader.dataset)
    std /= len(data_loader.dataset)

    print('mean', mean)
    print('std', std)
