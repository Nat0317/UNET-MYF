"""
这是旧的评估方法代码。

代码中计算precision的方法与paper中广泛运用的方法不同，
请使用新的方法 evals.py
"""

import os
import argparse
import numpy as np
import scipy
import imageio
from scipy.ndimage import map_coordinates

parser = argparse.ArgumentParser(description='polyp_evaluation')
parser.add_argument('--iou-threshold', type=float, default=0.5,
                    help='width of an image')

opt = parser.parse_args()


def remove_small_area(mask, small_mask_threshold):
    label_im, nb_labels = scipy.ndimage.label(mask)
    sizes = scipy.ndimage.sum(mask, label_im, range(nb_labels + 1))
    valid_seg_indices = []
    for seg_index, seg_size in enumerate(sizes):
        if seg_size > 1:
            valid_seg_indices.append(seg_index)

    mask_size = sizes < small_mask_threshold
    remove_pixel = mask_size[label_im]
    # remove those tiny masks
    label_im[remove_pixel] = 0
    return label_im


def bb_intersection_over_union(boxA, boxB):
    # determine the (x, y)-coordinates of the intersection rectangle
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    # compute the area of intersection rectangle
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)

    # compute the area of both the prediction and ground-truth
    # rectangles
    boxAArea = (boxA[2] - boxA[0] + 1) * (boxA[3] - boxA[1] + 1)
    boxBArea = (boxB[2] - boxB[0] + 1) * (boxB[3] - boxB[1] + 1)

    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = interArea / float(boxAArea + boxBArea - interArea)

    # return the intersection over union value
    return iou


def get_recall_and_precision(ground_truth_path, prediction_path):
    total_mask = 0.0
    total_pred_mask = 0.0
    correct_prediction = 0.0

    for filename in os.listdir(ground_truth_path):

        mask_gt = imageio.imread(os.path.join(ground_truth_path, filename))
        mask_pred = imageio.imread(os.path.join(prediction_path, filename))
        mask_gt = (mask_gt == 255)
        mask_pred = (mask_pred == 255)

        mask_gt = remove_small_area(mask_gt, 10)
        mask_pred = remove_small_area(mask_pred, 60)

        mask_gt_label_im, mask_gt_nb_labels = scipy.ndimage.label(mask_gt)
        mask_pred_label_im, mask_pred_nb_labels = scipy.ndimage.label(mask_pred)

        mask_gt_rois = np.array([(mask_gt_label_im == ii) * 1 for ii in range(1, mask_gt_nb_labels + 1)])
        mask_pred_rois = np.array([(mask_pred_label_im == ii) * 1 for ii in range(1, mask_pred_nb_labels + 1)])

        for rix_pred, r_pred in enumerate(mask_pred_rois):
            if np.sum(r_pred != 0) > 0:
                total_pred_mask += 1

        for rix, r in enumerate(mask_gt_rois):
            if np.sum(r != 0) > 0:  # check if the lesion survived data augmentation
                seg_ixs = np.argwhere(r != 0)
                mask_gt_coord_list = [np.min(seg_ixs[:, 1]) - 1, np.min(seg_ixs[:, 0]) - 1,
                                      np.max(seg_ixs[:, 1]) + 1, np.max(seg_ixs[:, 0]) + 1]
                total_mask += 1
                for rix_pred, r_pred in enumerate(mask_pred_rois):
                    if np.sum(r_pred != 0) > 0:
                        seg_pred_isx = np.argwhere(r_pred != 0)
                        mask_pred_coord_list = [np.min(seg_pred_isx[:, 1]) - 1, np.min(seg_pred_isx[:, 0]) - 1,
                                                np.max(seg_pred_isx[:, 1]) + 1, np.max(seg_pred_isx[:, 0]) + 1]
                        iou = bb_intersection_over_union(mask_gt_coord_list, mask_pred_coord_list)
                        if iou > opt.iou_threshold:
                            correct_prediction += 1
                            break
    recall = correct_prediction / total_mask
    precision = correct_prediction / total_pred_mask
    return recall, precision


if __name__ == '__main__':
    ground_truth_path = '/home/xinzi/ExtDisk/polyp_detection_data/CVC-ClinicDB_augmentation/test/GroundTruth'
    prediction_path = '/home/xinzi/ExtDisk/polyp_detection_model/' \
                      'UNet_CVC-ClinicDB_augmentation_5e-05_650_adam_cosine_step_interpolate/test_mask'
    recall, precision = get_recall_and_precision(ground_truth_path, prediction_path)
    print('Recall: ', format(recall, '.2%'))
    print('Precision: ', format(precision, '.2%'))
