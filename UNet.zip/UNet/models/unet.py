from models.unet_parts import *
from models.attention import SoftAttn
from torchvision.models.resnet import resnet50, Bottleneck
from models.deeplab.backbone.resnet import ResNet50, Bottleneck
from models.deeplab.sync_batchnorm.batchnorm import SynchronizedBatchNorm2d
import torch.nn.functional as F
from models.deeplab.aspp import build_aspp


class UNet(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm, attention):
        super(UNet, self).__init__()
        self.attention = attention

        self.down1 = Down(n_channels, 64, batch_norm)
        if self.attention is True:
            self.soft1 = SoftAttn(64)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        if self.attention is True:
            self.soft2 = SoftAttn(128)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        if self.attention is True:
            self.soft3 = SoftAttn(256)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        if self.attention is True:
            self.soft4 = SoftAttn(512)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 512, batch_norm)
        if self.attention is True:
            self.soft5 = SoftAttn(512)

        self.up1 = Up(1024, 256, up_mode, batch_norm)
        self.up2 = Up(512, 128, up_mode, batch_norm)
        self.up3 = Up(256, 64, up_mode, batch_norm)
        self.up4 = Up(128, 64, up_mode, batch_norm)
        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        # if self.attention is True:
        #     c1 = self.soft1(c1) * c1
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        # if self.attention is True:
        #     c2 = self.soft2(c2) * c2
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        # if self.attention is True:
        #     c3 = self.soft3(c3) * c3
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        # if self.attention is True:
        #     c4 = self.soft4(c4) * c4
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (512, 32, 24)
        # if self.attention is True:
        #     c5 = self.soft5(c5) * c5

        x = self.up1(c5, c4)
        x = self.up2(x, c3)
        x = self.up3(x, c2)
        x = self.up4(x, c1)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNetD(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNetD, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.up1 = Up(2048, 512, up_mode, batch_norm)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.up3 = Up(512, 128, up_mode, batch_norm)
        self.up4 = Up(256, 64, up_mode, batch_norm)
        self.up5 = Up(128, 64, up_mode, batch_norm)

        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (1024, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)

        x = self.up1(c6, c5)
        x = self.up2(x, c4)
        x = self.up3(x, c3)
        x = self.up4(x, c2)  # size=(N, 64, x.H/2, x.W/2)
        x = self.up5(x, c1)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNet64D(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNet64D, self).__init__()

        self.down1 = Down(n_channels, 32, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(32, 64, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(64, 128, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(128, 256, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(256, 512, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(512, 1024, batch_norm)
        self.pool6 = nn.MaxPool2d(2)

        self.down7 = Down(1024, 1024, batch_norm)

        self.up1 = Up(2048, 512, up_mode, batch_norm)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.up3 = Up(512, 128, up_mode, batch_norm)
        self.up4 = Up(256, 64, up_mode, batch_norm)
        self.up5 = Up(128, 32, up_mode, batch_norm)
        self.up6 = Up(64, 32, up_mode, batch_norm)

        self.outconv = OutConv(32, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (32, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (64, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (128, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (256, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (512, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)
        p6 = self.pool6(c6)  # (1024, 8, 6)

        c7 = self.down7(p6)  # (1024, 8, 6)

        x = self.up1(c7, c6)
        x = self.up2(x, c5)
        x = self.up3(x, c4)
        x = self.up4(x, c3)
        x = self.up5(x, c2)  # size=(N, 64, x.H/2, x.W/2)
        x = self.up6(x, c1)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNet4(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNet4, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.up1 = Up(2048, 512, up_mode, batch_norm)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.up3 = Up(512, 256, up_mode, batch_norm)
        # self.up4 = Up(256, 64, up_mode, batch_norm)
        # self.up5 = Up(128, 64, up_mode, batch_norm)

        self.relu = nn.ReLU(inplace=True)

        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(64)

        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (1024, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)

        x = self.up1(c6, c5)
        x = self.up2(x, c4)
        x = self.up3(x, c3)
        x = self.bn4(self.relu(self.deconv4(x)))  # size=(N, 64, x.H/2, x.W/2)
        x = self.bn5(self.relu(self.deconv5(x)))  # size=(N, 32, x.H, x.W)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNet8(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNet8, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.up1 = Up(2048, 512, up_mode, batch_norm)
        self.up2 = Up(1024, 512, up_mode, batch_norm)
        # self.up3 = Up(512, 128, up_mode, batch_norm)
        # self.up4 = Up(256, 64, up_mode, batch_norm)
        # self.up5 = Up(128, 64, up_mode, batch_norm)

        self.relu = nn.ReLU(inplace=True)

        self.deconv3 = nn.ConvTranspose2d(512, 256, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn3 = nn.BatchNorm2d(256)
        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(64)

        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (1024, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)

        x = self.up1(c6, c5)
        x = self.up2(x, c4)
        x = self.bn3(self.relu(self.deconv3(x)))  # size=(N, 128, x.H/4, x.W/4)
        x = self.bn4(self.relu(self.deconv4(x)))  # size=(N, 64, x.H/2, x.W/2)
        x = self.bn5(self.relu(self.deconv5(x)))  # size=(N, 32, x.H, x.W)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNet16(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNet16, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.up1 = Up(2048, 1024, up_mode, batch_norm)

        self.relu = nn.ReLU(inplace=True)

        self.deconv2 = nn.ConvTranspose2d(1024, 512, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn2 = nn.BatchNorm2d(512)
        self.deconv3 = nn.ConvTranspose2d(512, 256, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn3 = nn.BatchNorm2d(256)
        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(64)

        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (1024, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)

        x = self.up1(c6, c5)
        x = self.bn2(self.relu(self.deconv2(x)))
        x = self.bn3(self.relu(self.deconv3(x)))  # size=(N, 128, x.H/4, x.W/4)
        x = self.bn4(self.relu(self.deconv4(x)))  # size=(N, 64, x.H/2, x.W/2)
        x = self.bn5(self.relu(self.deconv5(x)))  # size=(N, 32, x.H, x.W)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNet32(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNet32, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.relu = nn.ReLU(inplace=True)

        self.deconv1 = nn.ConvTranspose2d(1024, 1024, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn1 = nn.BatchNorm2d(1024)
        self.deconv2 = nn.ConvTranspose2d(1024, 512, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn2 = nn.BatchNorm2d(512)
        self.deconv3 = nn.ConvTranspose2d(512, 256, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn3 = nn.BatchNorm2d(256)
        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(64)

        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (1024, 32, 24)
        p5 = self.pool5(c5)

        c6 = self.down6(p5)  # (1024, 16, 12)

        x = self.bn1(self.relu(self.deconv1(c6)))
        x = self.bn2(self.relu(self.deconv2(x)))
        x = self.bn3(self.relu(self.deconv3(x)))  # size=(N, 128, x.H/4, x.W/4)
        x = self.bn4(self.relu(self.deconv4(x)))  # size=(N, 64, x.H/2, x.W/2)
        x = self.bn5(self.relu(self.deconv5(x)))  # size=(N, 32, x.H, x.W)
        x = self.outconv(x)
        return F.sigmoid(x)


class UNetMutiOutputs(nn.Module):
    def __init__(self, n_channels, n_classes, up_mode, batch_norm):
        super(UNetMutiOutputs, self).__init__()

        self.down1 = Down(n_channels, 64, batch_norm)
        self.pool1 = nn.MaxPool2d(2)

        self.down2 = Down(64, 128, batch_norm)
        self.pool2 = nn.MaxPool2d(2)

        self.down3 = Down(128, 256, batch_norm)
        self.pool3 = nn.MaxPool2d(2)

        self.down4 = Down(256, 512, batch_norm)
        self.pool4 = nn.MaxPool2d(2)

        self.down5 = Down(512, 1024, batch_norm)
        self.pool5 = nn.MaxPool2d(2)

        self.down6 = Down(1024, 1024, batch_norm)

        self.up1 = Up(1024, 256, up_mode, batch_norm)
        self.up2 = Up(512, 128, up_mode, batch_norm)
        self.up3 = Up(256, 64, up_mode, batch_norm)
        self.up4 = Up(128, 64, up_mode, batch_norm)

        self.relu = nn.ReLU(inplace=True)

        self.deconv3 = nn.ConvTranspose2d(512, 256, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn3 = nn.BatchNorm2d(256)
        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(64)

        self.outconv1 = OutConv(64, n_classes)
        self.outconv2 = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 512, 384)
        p1 = self.pool1(c1)

        c2 = self.down2(p1)  # (128, 256, 192)
        p2 = self.pool2(c2)

        c3 = self.down3(p2)  # (256, 128, 96)
        p3 = self.pool3(c3)

        c4 = self.down4(p3)  # (512, 64, 48)
        p4 = self.pool4(c4)

        c5 = self.down5(p4)  # (512, 32, 24)

        x = self.up1(c5, c4)

        x1 = self.bn3(self.relu(self.deconv3(x)))
        x1 = self.bn4(self.relu(self.deconv4(x1)))  # size=(N, 64, x.H/2, x.W/2)
        x1 = self.bn5(self.relu(self.deconv5(x1)))  # size=(N, 32, x.H, x.W)
        x1 = self.outconv2(x1)

        x2 = self.up2(x, c3)
        x2 = self.up3(x2, c2)
        x2 = self.up4(x2, c1)
        x2 = self.outconv2(x2)

        return F.sigmoid(x1), F.sigmoid(x2)


class UNetRes50(nn.Module):
    def __init__(self, n_classes, up_mode, batch_norm):
        super(UNetRes50, self).__init__()

        resnet = resnet50(pretrained=True)

        self.down1 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
        )
        self.down2 = nn.Sequential(resnet.maxpool, resnet.layer1)
        self.down3 = resnet.layer2
        self.down4 = resnet.layer3
        self.down5 = resnet.layer4

        # self.down5 = nn.Sequential(
        #     Bottleneck(1024, 512, downsample=nn.Sequential(nn.Conv2d(1024, 2048, 1, bias=False), nn.BatchNorm2d(2048))),
        #     Bottleneck(2048, 512),
        #     Bottleneck(2048, 256, downsample=nn.Sequential(nn.Conv2d(2048, 1024, 1, bias=False), nn.BatchNorm2d(1024)))
        # )

        self.up1 = Up(3072, 512, up_mode, batch_norm)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.up3 = Up(512, 64, up_mode, batch_norm)
        self.up4 = Up(128, 64, up_mode, batch_norm)
        # self.relu = nn.ReLU(inplace=True)
        self.up5 = nn.ConvTranspose2d(64, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        # self.bn = nn.BatchNorm2d(64)
        self.outconv = OutConv(64, n_classes)

    def forward(self, x):
        c1 = self.down1(x)  # (64, 192, 192)
        c2 = self.down2(c1)  # (256, 96, 96)
        c3 = self.down3(c2)  # (512, 48, 48)
        c4 = self.down4(c3)  # (1024, 24, 24)
        c5 = self.down5(c4)  # (2048, 12, 12)

        x = self.up1(c5, c4)
        x = self.up2(x, c3)
        x = self.up3(x, c2)
        x = self.up4(x, c1)
        # x = self.bn(self.relu(self.up5(x)))
        x = self.up5(x)

        x = self.outconv(x)
        return F.sigmoid(x)


class Res50DeepLab(nn.Module):
    def __init__(self, n_classes):
        super(Res50DeepLab, self).__init__()

        # resnet = resnet50(pretrained=True)
        resnet = ResNet50(16, SynchronizedBatchNorm2d)

        self.down0 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool
        )

        self.down1 = resnet.layer1
        self.down2 = resnet.layer2
        self.down3 = resnet.layer3
        self.down4 = resnet.layer4

        self.up1 = nn.Sequential(nn.Conv2d(256, 48, 1, bias=False),
                                 nn.BatchNorm2d(48),
                                 nn.ReLU(inplace=True)
                                 )
        self.up2 = nn.Sequential(nn.Conv2d(512, 48, 1, bias=False),
                                 nn.BatchNorm2d(48),
                                 nn.ReLU(inplace=True)
                                 )
        self.up3 = nn.Sequential(nn.Conv2d(1024, 48, 1, bias=False),
                                 nn.BatchNorm2d(48),
                                 nn.ReLU(inplace=True)
                                 )
        self.up4 = nn.Sequential(nn.Conv2d(2048, 256, 1, bias=False),
                                 nn.BatchNorm2d(256),
                                 nn.ReLU(inplace=True)
                                 )

        # self.last_conv = nn.Sequential(nn.Conv2d(400, 256, kernel_size=3, stride=1, padding=1, bias=False),
        #                                nn.BatchNorm2d(256),
        #                                nn.ReLU(inplace=True),
        #                                nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
        #                                nn.BatchNorm2d(256),
        #                                nn.ReLU(inplace=True),
        #                                nn.Conv2d(256, n_classes, kernel_size=1, stride=1))

        self.last_conv = OutConv(400, n_classes)

    def forward(self, x):
        x = self.down0(x)  # (256, 192, 192)
        c1 = self.down1(x)  # (256, 96, 96)
        c2 = self.down2(c1)  # (512, 48, 48)
        c3 = self.down3(c2)  # (1024, 24, 24)
        c4 = self.down4(c3)  # (2048, 12, 12)

        c4 = F.interpolate(self.up4(c4), scale_factor=16, mode='bilinear', align_corners=True)
        c3 = F.interpolate(self.up3(c3), scale_factor=16, mode='bilinear', align_corners=True)
        c2 = F.interpolate(self.up2(c2), scale_factor=8, mode='bilinear', align_corners=True)
        c1 = F.interpolate(self.up1(c1), scale_factor=4, mode='bilinear', align_corners=True)

        x = torch.cat((c4, c3, c2, c1), dim=1)
        x = self.last_conv(x)

        return F.sigmoid(x)


class UNetRes50DeepLab(nn.Module):
    def __init__(self, n_classes, up_mode, batch_norm):
        super(UNetRes50DeepLab, self).__init__()

        # resnet = resnet50(pretrained=True)
        resnet = ResNet50(16, SynchronizedBatchNorm2d)

        self.down0 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool
        )

        self.down1 = resnet.layer1
        self.down2 = resnet.layer2
        self.down3 = resnet.layer3
        self.down4 = resnet.layer4

        self.reduction = nn.Conv2d(3072, 512, kernel_size=1)
        self.up1 = DoubleConv(512, 512, batch_norm)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.up3 = Up(512, 256, up_mode, batch_norm)

        self.last_conv = nn.Sequential(nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
        					   nn.BatchNorm2d(256),
        					   nn.ReLU(inplace=True),
        					   nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
        					   nn.BatchNorm2d(256),
        					   nn.ReLU(inplace=True),
        					   nn.Conv2d(256, n_classes, kernel_size=1, stride=1))

        # self.last_conv = OutConv(256, n_classes)

    def forward(self, x):
        x = self.down0(x)  # (64, 192, 192)
        c1 = self.down1(x)  # (256, 96, 96)
        c2 = self.down2(c1)  # (512, 48, 48)
        c3 = self.down3(c2)  # (1024, 24, 24)
        c4 = self.down4(c3)  # (2048, 24, 24)

        x = torch.cat((c4, c3), dim=1)
        x = self.reduction(x)
        x = self.up1(x)
        x = self.up2(x, c2)
        x = self.up3(x, c1)
        x = F.interpolate(x, scale_factor=4, mode='bilinear', align_corners=True)

        x = self.last_conv(x)

        return F.sigmoid(x)



class Attention(nn.Module):
    def __init__(self, n_classes, up_mode, batch_norm,):
        super(Attention, self).__init__()

        resnet = ResNet50(16, SynchronizedBatchNorm2d)

        self.down0 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool
        )

        self.down1 = resnet.layer1
        self.down2 = resnet.layer2
        self.down3 = resnet.layer3
        self.down4 = resnet.layer4

        # self.aspp = build_aspp('resnet50', 16, SynchronizedBatchNorm2d)

        self.reduction = nn.Conv2d(3078, 512, kernel_size=1)
        self.up1 = DoubleConv(512, 512, batch_norm)
        self.attention1 = SoftAttn(512)
        self.up2 = Up(1024, 256, up_mode, batch_norm)
        self.attention2 = SoftAttn(256)
        self.up3 = Up(512, 256, up_mode, batch_norm)
        self.attention3 = SoftAttn(256)

        # self.last_conv = nn.Sequential(nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
        # 					   nn.BatchNorm2d(256),
        # 					   nn.ReLU(inplace=True),
        # 					   nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
        # 					   nn.BatchNorm2d(256),
        # 					   nn.ReLU(inplace=True),
        # 					   nn.Conv2d(256, n_classes, kernel_size=1, stride=1))


        self.last_conv = OutConv(256, n_classes)

    def forward(self, x):
        x = self.down0(x)  # (64, 192, 192)
        c1 = self.down1(x)  # (256, 96, 96)
        c2 = self.down2(c1)  # (512, 48, 48)
        c3 = self.down3(c2)  # (1024, 24, 24)
        c4 = self.down4(c3)  # (2048, 24, 24)

        # c4 = self.aspp(c4)

        x = torch.cat((c4, c3), dim=1)
        x = self.reduction(x)
        x = self.up1(x)
        x = self.attention1(x) * x

        x = self.up2(x, c2)
        x = self.attention2(x) * x

        x = self.up3(x, c1)
        x = self.attention3(x)

        x = F.interpolate(x, scale_factor=4, mode='bilinear', align_corners=True)

        x = self.last_conv(x)

        return F.sigmoid(x)
