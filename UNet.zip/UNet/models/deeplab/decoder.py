import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from models.deeplab.sync_batchnorm.batchnorm import SynchronizedBatchNorm2d

class Decoder(nn.Module):
    def __init__(self, num_classes, backbone, BatchNorm):
        super(Decoder, self).__init__()
        if backbone == 'resnet50' or backbone == 'drn' or backbone == 'resnet10':
            c1_inplanes = 256
            c2_inplanes = 512
            c3_inplanes = 1024
        elif backbone == 'xception':
            low_level_inplanes = 128
        elif backbone == 'mobilenet':
            low_level_inplanes = 24
        else:
            raise NotImplementedError

        self.conv1 = nn.Conv2d(c1_inplanes, 48, 1, bias=False)
        self.conv2 = nn.Conv2d(c2_inplanes, 48, 1, bias=False)
        self.conv3 = nn.Conv2d(c3_inplanes, 48, 1, bias=False)
        self.bn = BatchNorm(48)
        self.relu = nn.ReLU(inplace=True)
        self.last_conv = nn.Sequential(nn.Conv2d(400, 256, kernel_size=3, stride=1, padding=1, bias=False),
                                       BatchNorm(256),
                                       nn.ReLU(inplace=True),
                                       nn.Dropout(0.5),
                                       nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False),
                                       BatchNorm(256),
                                       nn.ReLU(inplace=True),
                                       nn.Dropout(0.1),
                                       nn.Conv2d(256, num_classes, kernel_size=1, stride=1))
        self._init_weight()


    def forward(self, c1, c2, c3, x):
        c1 = self.relu(self.bn(self.conv1(c1)))
        c2 = self.relu(self.bn(self.conv2(c2)))
        c3 = self.relu(self.bn(self.conv3(c3)))

        c1 = F.interpolate(c1, size=(384, 384), mode='bilinear', align_corners=True)
        c2 = F.interpolate(c2, size=(384, 384), mode='bilinear', align_corners=True)
        c3 = F.interpolate(c3, size=(384, 384), mode='bilinear', align_corners=True)
        x = F.interpolate(x, size=(384, 384), mode='bilinear', align_corners=True)
        x = torch.cat((x, c3, c2, c1), dim=1)
        x = self.last_conv(x)

        return x

    def _init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                torch.nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, SynchronizedBatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

def build_decoder(num_classes, backbone, BatchNorm):
    return Decoder(num_classes, backbone, BatchNorm)