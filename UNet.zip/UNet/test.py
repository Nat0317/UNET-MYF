import time
import datetime
import os
import json
import imageio
import argparse
import torch
import shutil
import matplotlib.pyplot as plt
import numpy as np
from torchvision import transforms
from models.unet import UNet, UNetD, UNet4, UNet8, UNet16, UNet32, UNetMutiOutputs, UNetRes50, Res50DeepLab, UNetRes50DeepLab
import PIL.Image as Image
from utils.utils import smooth_mask
from utils.dice_loss import dice_coeff
from utils.evals import *
# from utils.crf import DenseCRF, dense_crf
from models.deeplab.deeplab import *

parser = argparse.ArgumentParser(description='polyp_predict')

parser.add_argument('--image-folder-path',
                    default='/home/xinzi/ExtDisk/polyp_detection_data/large_dataset_90000/test/',
                    help='path of dataset')

parser.add_argument('--image-file-num', type=int, default=None,
                    help='width of an image')

parser.add_argument('--threshold', type=float, default=0.5,
                    help='threshold to classify as polyp for each pixel')

parser.add_argument('--small-mask-threshold', type=int, default=80,
                    help='mask smaller than the threshold would be eliminated')

parser.add_argument('--model-path',
                    default='/home/xinzi/ExtDisk/polyp_detection_model'
                            '/Res50DeepLab_large_dataset_90000_1e-05_80_adam_cosine_step_interpolate_bce',
                    help='path of model file')

parser.add_argument('--iou-threshold', type=float, default=0.0001,
                    help='iou > threshold will be classified as True Positive')

parser.add_argument('--combine-close-bbox', action='store_true',
                    help='combine close bbox or not')

parser.add_argument('--smooth', action='store_true',
                    help='smooth the prediction mask or not')

parser.add_argument('--eval-mode', type=str, default='center',
                    choices=['iou', 'center'],
                    help='combine close bbox or not')

parser.add_argument('--crf', action='store_true',
                    help='whether use crf for post process')

opt = parser.parse_args()

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def plot_img_and_mask(img, mask, original_mask):
    fig = plt.figure()
    a = fig.add_subplot(1, 3, 1)
    a.set_title('Input image')
    plt.imshow(img)

    b = fig.add_subplot(1, 3, 2)
    b.set_title('Output mask')
    plt.imshow(mask, cmap='gray')

    b = fig.add_subplot(1, 3, 3)
    b.set_title('Original mask')
    plt.imshow(original_mask, cmap='gray')
    plt.show()


def get_output_filenames(args):
    in_files = args.input
    out_files = []

    if not args.output:
        for f in in_files:
            pathsplit = os.path.splitext(f)
            out_files.append("{}_OUT{}".format(pathsplit[0], pathsplit[1]))
    elif len(in_files) != len(args.output):
        print('Error : Input files and output files are not of the same length')
        raise SystemExit()
    else:
        out_files = args.output

    return out_files


def mask_to_image(mask):
    mask = (mask * 255).astype(np.uint8)
    mask = smooth_mask(mask)
    return Image.fromarray(mask)


def main():
    args = json.load(open(os.path.join(opt.model_path, 'args.txt')))
    up_mode = args['up_mode']
    batch_norm = args['batch_norm']
    model = args['model']
    # attention = args['attention']

    model_path = opt.model_path
    for filename in os.listdir(model_path):
        if filename.find('model_') != -1:
            model_path = os.path.join(model_path, filename)
            break

    loading_start_time = time.time()
    print('Start loading model')

    if model == 'UNet':
        model = UNet(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm,
                     attention=args.attention).to(device)
    elif model == 'UNetD':
        model = UNetD(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNet4':
        model = UNet4(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNet8':
        model = UNet8(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNet16':
        model = UNet16(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNet32':
        model = UNet32(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNetRes50':
        model = UNetRes50(n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'UNetMutiOutputs':
        model = UNetMutiOutputs(n_channels=3, n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)
    elif model == 'DeepLab':
        model = DeepLab(n_classes=1).to(device)
    elif model == 'Res50DeepLab':
        model = Res50DeepLab(n_classes=1).to(device)
    elif model == 'UNetRes50DeepLab':
        model = UNetRes50DeepLab(n_classes=1, up_mode=up_mode, batch_norm=batch_norm).to(device)

    model.load_state_dict(torch.load(model_path, map_location=device)['state_dict'])
    loading_elapsed = time.time() - loading_start_time
    loading_elapsed = str(datetime.timedelta(seconds=loading_elapsed))
    print('\nModel loaded ! Loading elapsed: %s' % loading_elapsed)

    inference_time = 0
    if opt.image_file_num is None:
        acc = 0.0
        process_start_time = time.time()
        wrong_num = 0
        for filename in os.listdir(os.path.join(opt.image_folder_path, 'Original')):
            original_mask_path = os.path.join(opt.image_folder_path, 'GroundTruth', filename)

            image_path = os.path.join(opt.image_folder_path, 'Original', filename)
            if opt.crf:
                crf = True
            else:
                crf = False
            single_acc, single_inference_time = test(model, image_path, original_mask_path=original_mask_path, filename=filename,
                              save_image=True, densecrf=crf)
            if single_acc < 0.667:
                # print(filename, single_acc)
                wrong_num += 1
            acc = acc + single_acc
            inference_time += single_inference_time

        process_elapsed = time.time() - process_start_time
        process_elapsed = str(datetime.timedelta(seconds=process_elapsed))
        print('\nProcessing elapsed: %s' % process_elapsed)
        print('Dice Coeff: %f' % (acc / len(os.listdir(os.path.join(opt.image_folder_path, 'Original')))))
        print('%d images predicted wrong.' % wrong_num)

        original_image_path = os.path.join(opt.image_folder_path, 'Original')
        ground_truth_path = os.path.join(opt.image_folder_path, 'GroundTruth')
        prediction_path = os.path.join(opt.model_path, 'prediction')

        evaluation_path = os.path.join(opt.model_path, 'evaluation')
        if not os.path.isdir(evaluation_path):
            os.makedirs(evaluation_path)
        else:
            shutil.rmtree(evaluation_path)
            os.makedirs(evaluation_path)
        evaluation_metric = Evaluation(visualization_root=evaluation_path, visualize=True,
                                       iou_thresh=opt.iou_threshold, mode=opt.eval_mode)

        post_process_time = 0
        for filename in os.listdir(ground_truth_path):
            mask_gt_path = os.path.join(ground_truth_path, filename)
            mask_pred_path = os.path.join(prediction_path, filename)
            original_image = imageio.imread(os.path.join(original_image_path, filename))
            gt_coord, _ = evaluation_metric.get_coord_list(mask_gt_path, 10)
            post_process_start = time.time()
            pred_coord, pre_mask = evaluation_metric.get_coord_list(mask_pred_path, opt.small_mask_threshold)
            if opt.combine_close_bbox:
                pred_coord = evaluation_metric.merge_close_bbox(pred_coord)
            post_process_end = time.time()
            post_process_time += (post_process_end - post_process_start)
            image = apply_mask(original_image, pre_mask)
            evaluation_metric.eval_add_result(gt_coord, pred_coord, image, filename[:-4])

        precision, recall = evaluation_metric.get_result()
        f1_score = 2.0 * precision * recall / (precision + recall)

        inference_time = inference_time / 612
        post_process_time = post_process_time / 612
        inference_elapse = str(datetime.timedelta(seconds=inference_time))
        post_process_elapse = str(datetime.timedelta(seconds=post_process_time))

        print('Precision: ', format(precision, '.2%'))
        print('Recall: ', format(recall, '.2%'))
        print('F1_score: ', format(f1_score, '.2%'))
        print('Inference time: %s' % inference_elapse)
        print('Post process time: %s' % post_process_elapse)

    else:
        image_path = os.path.join(opt.image_folder_path, 'Original', str(opt.image_file_num) + '.tif')
        original_mask_path = os.path.join(opt.image_folder_path, 'GroundTruth', str(opt.image_file_num) + '.tif')
        test(model, image_path, original_mask_path=original_mask_path)


def test(model, image_path, filename=None, original_mask_path=None, save_image=False, densecrf=False):
    model.eval()
    # original_img = Image.open(image_path)
    original_img = imageio.imread(image_path)
    original_img = Image.fromarray(original_img)
    transform = transforms.Compose([
        transforms.Resize((384, 384), interpolation=3),
        transforms.ToTensor(),
        # transforms.Normalize(mean=[0.1744, 0.2773, 0.4399], std=[0.1347, 0.1921, 0.2863])     # cvc612
        # transforms.Normalize(mean=[0.3939, 0.4082, 0.4495], std=[0.2625, 0.2664, 0.2724])     # large dataset no cut
        transforms.Normalize(mean=[0.5697, 0.3530, 0.2163], std=[0.2067, 0.1586, 0.1252])       # large dataset cut
    ])
    inference_start_time = time.time()
    img = transform(original_img).to(device)
    img = img.unsqueeze(0)
    mask = model(img)  # output for calculation dice coeff

    mask_image = mask[0].squeeze(0).cpu().detach().numpy()  # mask_image: predict mask for plot
    if densecrf:
        mask_image = dense_crf(np.array(original_img.resize([384, 384])).astype(np.uint8), mask_image)
    mask_image = (mask_image > opt.threshold)
    inference_end_time = time.time()
    inference_elapse = inference_end_time - inference_start_time

    mask_image = mask_to_image(mask_image).resize((384, 384))

    mask = (mask > opt.threshold).float()
    target_transform = transforms.Compose([
        transforms.Resize((384, 384), interpolation=3),
        transforms.ToTensor()
    ])
    original_mask_image = Image.open(original_mask_path)  # original_mask_image: original mask for plot

    # original_mask_image_dice: ground truth for calculating dice coeff
    original_mask_image_dice = target_transform(original_mask_image)
    original_mask_image_dice = original_mask_image_dice.unsqueeze(0)
    original_mask_image_dice = original_mask_image_dice.to(device)
    acc = dice_coeff(mask, original_mask_image_dice).item()

    mask_image = mask_image.resize(original_img.size)

    if save_image:
        mask_save_path = os.path.join(opt.model_path, 'prediction')
        if not os.path.isdir(mask_save_path):
            os.makedirs(mask_save_path)
        mask_image.save(os.path.join(mask_save_path, filename))
        return acc, inference_elapse
    else:
        print('Dice Coeff: %f' % (acc))

        print('Visualizing results for image.')
        plot_img_and_mask(original_img, mask_image, original_mask_image)


if __name__ == '__main__':
    main()
