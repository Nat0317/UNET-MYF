from torch.utils.data import dataset, dataloader
from torchvision import transforms
import torchvision.transforms.functional as tf
import PIL.Image as Image
import os
import imageio
from sklearn.model_selection import train_test_split
from numpy import random
from utils.utils import *


class DataLoader:
    def __init__(self,
                 data_path,  # image_path
                 dataset_name,  # name of dataset
                 train_batch_size,
                 test_batch_size,
                 augmentation,  # whether to do the data augmentation
                 width=512,  # width of image after resize
                 height=384,  # height of image after resize
                 num_workers=8,  # number of data loading workers (tips: 4 or 8 times number of gpus)
                 pin_memory=True,  # whether to copy tensors into CUDA pinned memory before returning them
                 ):
        # if train_test_split:
        train_dataset = make_dataset(data_path, dataset_name, 'train')
        test_dataset = make_dataset(data_path, dataset_name, 'test')
        # else:
        #     train_dataset, test_dataset = make_train_test_dataset(data_path, dataset_name)

        train_dataset = PolypDataset(train_dataset, dataset_name, width, height, augmentation, 'train')
        test_dataset = PolypDataset(test_dataset, dataset_name, width, height, False, 'test')
        self.train_loader = dataloader.DataLoader(train_dataset, batch_size=train_batch_size, shuffle=True,
                                                  num_workers=num_workers, pin_memory=pin_memory)
        self.test_loader = dataloader.DataLoader(test_dataset, batch_size=test_batch_size, shuffle=True,
                                                 num_workers=num_workers, pin_memory=pin_memory)


def make_train_test_dataset(data_path, dataset_name):
    imgs = []
    root = os.path.join(data_path, dataset_name)

    n = len(os.listdir(root + '/Original/'))
    for i in range(1, n + 1):
        img = os.path.join(root, 'Original/%d.tif' % i)
        mask = os.path.join(root, 'GroundTruth/%d.tif' % i)
        imgs.append((img, mask))

    imgs_train, imgs_test = train_test_split(imgs, test_size=0.2)
    return imgs_train, imgs_test


def make_dataset(data_path, dataset_name, mode):
    imgs = []
    root = os.path.join(data_path, dataset_name, mode)

    for filename in os.listdir(os.path.join(root, 'Original')):
        img = os.path.join(root, 'Original', filename)
        mask = os.path.join(root, 'GroundTruth', filename)
        if mode == 'train':
            contour = os.path.join(root, 'Contour', filename)
            imgs.append((img, mask, contour))
        else:
            imgs.append((img, mask))
    return imgs


class PolypDataset(dataset.Dataset):
    def __init__(self, imgs, dataset_name, width, height, augmentation, mode):
        self.imgs = imgs
        self.dataset_name = dataset_name
        self.width = width
        self.height = height
        self.augmentation = augmentation
        self.mode = mode

    def __getitem__(self, index):
        if self.mode == 'train':
            x_path, y_path, contour_path = self.imgs[index]
            img_x = Image.open(x_path)
            img_y = Image.open(y_path)
            # mask = imageio.imread(y_path)
            # mask = cv.resize(mask, (self.width, self.height))
            # contour = find_contours(mask)
            # contour = Image.fromarray(contour)
            contour = Image.open(contour_path)
        else:
            x_path, y_path = self.imgs[index]
            img_x = Image.open(x_path)
            img_y = Image.open(y_path)
            contour = Image.fromarray(np.zeros(img_x.size)) # would not be used in validation phase

        if self.augmentation is True:
            img_x, img_y, contour = self.my_transforms(img_x, img_y, contour, width=self.width, height=self.height)
        else:
            train_transform = transforms.Compose([
                transforms.Resize((self.width, self.height), interpolation=3),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5697, 0.3530, 0.2163], std=[0.2067, 0.1586, 0.1252])
            ])
            target_transform = transforms.Compose([
                transforms.Resize((self.width, self.height), interpolation=3),
                transforms.Grayscale(num_output_channels=1),
                transforms.ToTensor()
            ])
            img_x = train_transform(img_x)
            img_y = target_transform(img_y)
            contour = target_transform(contour)
        return img_x, img_y, contour

    def __len__(self):
        return len(self.imgs)

    @staticmethod
    def my_transforms(image, mask, contour, width, height):
        resize = transforms.Resize(size=(width, height))
        image = resize(image)
        mask = resize(mask)
        contour = resize(contour)

        # Random crop
        # i, j, h, w = transforms.RandomCrop.get_params(
        #     image, output_size=(512, 512))
        # image = tf.crop(image, i, j, h, w)
        # mask = tf.crop(mask, i, j, h, w)

        # Vertical flipping
        if random.random() > 0.5:
            image = tf.vflip(image)
            mask = tf.vflip(mask)
            contour = tf.vflip(contour)

        # Rotate (90, 180, 270)
        if random.random() > 0.5:
            image = tf.rotate(image, 90)
            mask = tf.rotate(mask, 90)
            contour = tf.rotate(contour, 90)
        if random.random() > 0.5:
            image = tf.rotate(image, 180)
            mask = tf.rotate(mask, 180)
            contour = tf.rotate(contour, 180)
        if random.random() > 0.5:
            image = tf.rotate(image, 270)
            mask = tf.rotate(mask, 270)
            contour = tf.rotate(contour, 270)

        # Transform to tensor
        image = tf.to_tensor(image)
        mask = tf.to_tensor(mask)
        contour = tf.to_tensor(contour)

        # Normalize
        image = tf.normalize(image, mean=[0.5697, 0.3530, 0.2163], std=[0.2067, 0.1586, 0.1252])

        return image, mask, contour
