from utils.dice_loss import dice_coeff


def validation(epoch, model, testloader, device, writer):
    model.eval()

    tot = 0.0
    sum = 0

    for batch_id, (x, y, _) in enumerate(testloader):
        x = x.to(device)  # [N, 1, H, W]
        y = y.to(device)  # [N, H, W] with class indices (0, 1)
        prediction = model(x)  # [N, 2, H, W]

        prediction = (prediction > 0.5).float()
        tot += dice_coeff(prediction, y).item()
        sum += 1

    acc = tot / sum
    epoch_val_result = 'Epoch[%d] - Validation Dice Coeff: %f\n' % (epoch, acc)
    print(epoch_val_result)

    writer.add_scalar('scalar/validation_acc', acc, epoch)

    return acc, epoch_val_result
